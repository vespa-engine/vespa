---
name: "schema-authoring"
description: "Writing, validating, and evolving Vespa .sd schema files."
---

# Schema authoring

Body content.
