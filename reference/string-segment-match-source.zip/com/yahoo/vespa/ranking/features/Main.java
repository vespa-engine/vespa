package com.yahoo.vespa.ranking.features;

/**
 * Helper for computing metrics from the command line.
 */
public class Main {

    public static void main(String[] args) {
        StringMatchMetricsComputer c=new StringMatchMetricsComputer();
        String query=getQuery(args);
        String field=getField(args);
        if (query==null || field==null) {
            printUsage();
            return;
        }

        c.compute(query,field);
        System.out.println(c.getMetrics().toStringDump());
    }

    private static String getQuery(String[] args) {
        if (args.length<1) return null;
        if (args[0].equals("-h") || args[0].equals("-help")) return null;
        return args[0];
    }

    private static String getField(String[] args) {
        if (args.length<2) return null;
        return args[1];
    }

    private static void printUsage() {
        System.out.println("Computes the string segment match metrics of a query and field.");
        System.out.println("Usage: java -jar ssm.jar query field");
        System.out.println("By: Jon Bratseth (bratseth@yahoo-inc.com)");
    }

}
