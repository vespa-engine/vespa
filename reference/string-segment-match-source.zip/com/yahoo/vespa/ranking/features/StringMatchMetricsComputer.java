package com.yahoo.vespa.ranking.features;

import java.util.*;

/**
 * <p>Calculates a set of metrics capturing information about the degree of agreement between a query
 * and a field string. This algorithm attempts to capture the property of text that very close tokens
 * are usuall part of the same semantic structure, while tokens farther apart are much more loosely related.
 * The algorithm will locate alternative such regions containing multiple query tokens (segments), do a more
 * detailed analysis of these segments and choose the ones producing the best overall set of match metrics.</p>
 *
 * <p>Such segments are found by looking at query terms in sequence from
 * left top right and finding matches in the field. All alternative segment start points are explored, and the
 * segmentation achieving the best overall string match metric score is preferred. The dynamic programming paradigm
 * is used to avoid redoing work on segmentations.</p>
 *
 * <p>When a segment start point is found, subsequenc tokens from the query are searched in the field
 * from this starting point in "semantic order". This search order can be defined independently of the
 * algorithm. The current order searches <i>proximityLimit tokens ahead first, then the same distance backwards
 * (so if you need to go two steps backwards in the field from the segment starting point, the real distance is -2,
 * but the "semantic distance" is proximityLimit+2.</p>
 *
 * <p>The actual metrics are calculated during execution of this algorithm by the {@link StringMatchMetrics} class,
 * by receiving events emitted from the algorithm. Any set of metrics derivable from these events a computable using
 * this algorithm.</p>
 *
 * <p>Terminology:
 * <ul>
 * <li><b>Sequence</b> - A set of adjacent matched tokens in the field
 * <li><b>Segment</b> - A field area containing matches to a continuous section of the query
 * <li><b>Gap</b> - A chunk of adjacent tokens <i>inside a segment</i> separating two matched characters
 * <li><b>Semantic distance</b> - A non-continuous distance between tokens in j, where the non-continuousness is
 * mean to capture the
 * </ul>
 *
 * <p>Notation: A position index in the query is denoted <code>i</code>. A position index in the field is
 * denoted <code>j</code>.</p>
 *
 * <p>This class is not multithread safe, but is reusable across queries for a single thread.</p>
 *
 * @author  <a href="mailto:bratseth@yahoo-inc.com">Jon Bratseth</a>
 * @version $Id$
 */
public final class StringMatchMetricsComputer {

    private Query query;

    private String[] field;

    private StringMatchMetricsParameters parameters=StringMatchMetricsParameters.defaultParameters();

    /** The metrics of the currently explored segmentation */
    private StringMatchMetrics currentMetrics;

    /** The final metrics, null during and before metric computation */
    private StringMatchMetrics finalMetrics;

    /**
     * Known segment starting points. The array is 0..i, one element per starting point query item i,
     * and a last element representing the entire query.
     */
    private List<SegmentStartPoint> segmentStartPoints=new ArrayList<SegmentStartPoint>();

    /** True to collect trace */
    private boolean collectTrace;

    private StringBuilder trace=new StringBuilder();

    private int alternativeSegmentationsTried=0;

    /** Computes the string match metrics from a query and field string. */
    public StringMatchMetrics compute(String queryString,String fieldString) {
        return compute(new Query(queryString),fieldString);
    }

    /** Computes the string match metrics from a query and field string. */
    public StringMatchMetrics compute(Query query,String fieldString) {
        // Reset state
        finalMetrics=null;
        this.query=query;
        this.field=fieldString.split(" ");
        segmentStartPoints.clear();
        for (int i=0; i<=query.getTerms().length; i++)
            segmentStartPoints.add(null);
        trace.setLength(0);
        alternativeSegmentationsTried=0;

        // Compute
        exploreSegments();

        return finalMetrics;
    }

    /** Finds segment candidates and explores them until we have the best segmentation history of the entire query */
    private void exploreSegments() {
        if (collectTrace)
            trace.append("Calculating matches for\n    " + query + "\n    field: " + Arrays.toString(field) + "\n");

        // Create an initial start point
        currentMetrics =new StringMatchMetrics();
        currentMetrics.initialize(this);
        SegmentStartPoint segmentStartPoint=new SegmentStartPoint(currentMetrics,this);
        segmentStartPoints.set(0,segmentStartPoint);

        // Explore segmentations
        while (segmentStartPoint!=null) {
            currentMetrics =segmentStartPoint.getMetrics().clone();
            if (collectTrace)
                trace.append("\nLooking for segment from " + segmentStartPoint + "..." + "\n");
            boolean found=findAlternativeSegmentFrom(segmentStartPoint);
            if (collectTrace)
                trace.append(found ? "...found segment: " + currentMetrics.getSegmentStarts() + " score: " +
                             currentMetrics.getSegmentationScore() : "...no complete and improved segment existed" + "\n");
            if (!found)
                segmentStartPoint.setOpen(false);
            segmentStartPoint=findOpenSegment(segmentStartPoint.getI());
        }

        finalMetrics=findLastStartPoint().getMetrics();
        setOccurrenceCounts(finalMetrics);
        finalMetrics.onComplete();
        finalMetrics.setComplete(true);
    }

    /**
     * Find correspondences from a segment starting point startI
     *
     * @return true if a segment was found, false if none could be found
     */
    private boolean findAlternativeSegmentFrom(SegmentStartPoint segmentStartPoint) {
        int semanticDistanceExplored=segmentStartPoint.getSemanticDistanceExplored();
        int previousI=-1;
        int previousJ=segmentStartPoint.getPreviousJ();
        boolean hasOpenSequence=false;
        boolean isFirst=true;

        for (int i=segmentStartPoint.getStartI(); i<query.getTerms().length; i++) {
            int semanticDistance=findClosestInFieldBySemanticDistance(i,previousJ,semanticDistanceExplored);
            int j=semanticDistanceToFieldIndex(semanticDistance,previousJ);

            if (j==-1 && semanticDistanceExplored>0 && isFirst) {
                return false; // Segment explored before, and no more matches found
            }

            if ( hasOpenSequence && ( j==-1 || j!=previousJ+1 ) ) {
                currentMetrics.onSequenceEnd(previousJ);
                hasOpenSequence=false;
            }

            if (isFirst) {
                if (j!=-1) {
                    segmentStart(i,j,isFirst ? -1 : previousJ);
                    segmentStartPoint.exploredTo(j);
                    isFirst=false;
                }
                else {
                    segmentStartPoint.incrementStartI(); // Remember that there are no matches for this i
                }
            }
            else {
                if (Math.abs(j-previousJ) >= parameters.getProximityLimit()) {
                    segmentEnd(i-1,previousJ);
                    return true;
                }
                else if (j!=-1) {
                    inSegment(i,j,previousJ,previousI);
                }
            }

            if (j!=-1)
                currentMetrics.onMatch(i,j);
            
            if (j!=-1 && !hasOpenSequence) {
                currentMetrics.onSequenceStart(j);
                hasOpenSequence=true;
            }

            if (j!=-1)
                semanticDistanceExplored=1; // Skip the current match when looking for the next
            else
                semanticDistanceExplored=0;

            if (j>=0) {
                previousI=i;
                previousJ=j;
            }
        }

        if (hasOpenSequence)
            currentMetrics.onSequenceEnd(previousJ);

        if (!isFirst) {
            segmentEnd(query.getTerms().length-1,previousJ);
            return true;
        }
        else {
            return false;
        }
    }

    /**
     * Implements the prefered search order for finding a match to a query item - first
     * looking close in the right order, then close in the reverse order, then far in the right order
     * and lastly far in the reverse order.
     *
     * @param startSemanticDistance is the semantic distance we must be larger than or equal to
     * @return the semantic distance of the next mathing j larger than startSemanticDistance, or -1 if
     *         there are no matches larger than startSemanticDistance
     */
    private int findClosestInFieldBySemanticDistance(int i,int previousJ,int startSemanticDistance) {
        String term=query.getTerms()[i].getTerm();
        for (int distance=startSemanticDistance; distance<field.length; distance++) {
            int j=semanticDistanceToFieldIndex(distance,previousJ);
            if (term.equals(field[j]))
                return distance;
        }
        return -1;
    }

    /**
     * Returns the field index (j) from a starting point zeroJ and the distance form zeroJ in the
     * semantic distance space
     *
     * @returns the field index, or -1 (undefined) if the semanticDistance is -1
     */
    public int semanticDistanceToFieldIndex(int semanticDistance,int zeroJ) {
        if (semanticDistance==-1) return -1;
        int firstSegmentLength=Math.min(parameters.getProximityLimit(),field.length-zeroJ);
        int secondSegmentLength=Math.min(parameters.getProximityLimit(),zeroJ);
        if (semanticDistance<firstSegmentLength)
            return zeroJ+semanticDistance;
        else if (semanticDistance<firstSegmentLength+secondSegmentLength)
            return zeroJ-semanticDistance-1+firstSegmentLength;
        else if (semanticDistance<field.length-zeroJ+secondSegmentLength)
            return zeroJ+semanticDistance-secondSegmentLength;
        else
            return field.length-semanticDistance-1;
    }

    /**
     * Returns the semantic distance from a starting point zeroJ to a field index j
     *
     * @returns the semantic distance, or -1 (undefined) if j is -1
     */
    public int fieldIndexToSemanticDistance(int j,int zeroJ) {
        if (j==-1) return -1;
        int firstSegmentLength=Math.min(parameters.getProximityLimit(),field.length-zeroJ);
        int secondSegmentLength=Math.min(parameters.getProximityLimit(),zeroJ);
        if (j>=zeroJ) {
            if ( (j-zeroJ) < firstSegmentLength )
                return j-zeroJ; // 0..limit
            else
                return j-zeroJ+secondSegmentLength; // limit*2..field.length-zeroJ
        }
        else {
            if ( (zeroJ-j-1) < secondSegmentLength )
                return zeroJ-j+firstSegmentLength-1; // limit..limit*2
            else
                return (zeroJ-j-1)+field.length-zeroJ; // field.length-zeroJ..
        }

    }

    private void inSegment(int i,int j,int previousJ,int previousI) {
        currentMetrics.onPair(i,j,previousJ);
        if (j==previousJ+1 && i==previousI+1) {
            currentMetrics.onInSequence(i,j,previousJ);
        }
        else {
            currentMetrics.onInSegmentGap(i,j,previousJ);
            if (collectTrace)
                trace.append("      in segment gap: " + i + "->" + j + " (" + query.getTerms()[i] + ")" + "\n");
        }
    }

    /** Returns whether this segment was accepted as a starting point */
    private boolean segmentStart(int i,int j,int previousJ) {        
        currentMetrics.onNewSegment(i,j,previousJ);

        if (previousJ>=0)
            currentMetrics.onPair(i,j,previousJ);

        if (collectTrace)
            trace.append("    new segment at:   " + i + "->" + j + " (" + query.getTerms()[i] + ")" + "\n");
        return true;
    }

    /**
     * Registers an end of a segment
     *
     * @param i the i at which this segment ends
     * @param j the j at which this segment ends
     */
    private void segmentEnd(int i,int j) {
        if (collectTrace)
            trace.append("    segment ended at: " + i + "->" + j + " (" + query.getTerms()[i] + ")" + "\n");
        SegmentStartPoint startOfNext=segmentStartPoints.get(i+1);
        if (startOfNext==null)
            segmentStartPoints.set(i+1,new SegmentStartPoint(i+1,j,currentMetrics,this));
        else
            startOfNext.offerHistory(j,currentMetrics);
    }

    /** Returns the next open segment to explore, or null if no more segments exists or should be explored */
    private SegmentStartPoint findOpenSegment(int startI) {
        for (int i=startI; i<segmentStartPoints.size(); i++) {
            SegmentStartPoint startPoint=segmentStartPoints.get(i);
            if (startPoint==null || !startPoint.isOpen()) continue;

            if (startPoint.getSemanticDistanceExplored()==0) return startPoint; // First attempt

            if (alternativeSegmentationsTried>=parameters.getMaxAlternativeSegmentations()) continue;
            alternativeSegmentationsTried++;
            return startPoint;
        }

        return null;
    }

    private SegmentStartPoint findLastStartPoint() {
        for (int i=segmentStartPoints.size()-1; i>=0; i--) {
            SegmentStartPoint startPoint=segmentStartPoints.get(i);
            if (startPoint!=null)
                return startPoint;
        }
        return null; // Impossible
    }

    /** Counts all occurrences of terms of the query in the field and set those metrics */
    private void setOccurrenceCounts(StringMatchMetrics metrics) {
        Set<QueryTerm> uniqueQueryTerms=new HashSet<QueryTerm>();
        for (QueryTerm queryTerm : query.getTerms())
            uniqueQueryTerms.add(queryTerm);

        List<Float> weightedOccurrences=new ArrayList<Float>();
        List<Float> significantOccurrences=new ArrayList<Float>();

        int divider=Math.min(field.length,parameters.getMaxOccurrences()*uniqueQueryTerms.size());
        int maxOccurence=Math.min(field.length,parameters.getMaxOccurrences());

        float occurrence=0;
        float absoluteOccurrence=0;
        float weightedAbsoluteOccurrence=0;
        int totalWeight=0;
        float totalWeightedOccurrences=0;
        float totalSignificantOccurrences=0;

        for (QueryTerm queryTerm : uniqueQueryTerms) {
            int termOccurrences=0;
            for (String fieldTerm : field) {
                if (fieldTerm.equals(queryTerm.getTerm()))
                    termOccurrences++;
                if (termOccurrences==parameters.getMaxOccurrences()) break;
            }
            occurrence+=(float)termOccurrences/divider;

            absoluteOccurrence+=(float)termOccurrences/(parameters.getMaxOccurrences()*uniqueQueryTerms.size());

            weightedAbsoluteOccurrence+=(float)termOccurrences*queryTerm.getWeight()/parameters.getMaxOccurrences();
            totalWeight+=queryTerm.getWeight();

            totalWeightedOccurrences+=(float)maxOccurence*queryTerm.getWeight()/divider;
            weightedOccurrences.add((float)termOccurrences*queryTerm.getWeight()/divider);

            totalSignificantOccurrences+=(float)maxOccurence*queryTerm.getSignificance()/divider;
            significantOccurrences.add((float)termOccurrences*queryTerm.getSignificance()/divider);
        }

        float weightedOccurrenceSum=0;
        for (float weightedOccurence : weightedOccurrences)
            weightedOccurrenceSum+=weightedOccurence/totalWeightedOccurrences;

        float significantOccurrenceSum=0;
        for (float significantOccurence : significantOccurrences)
            significantOccurrenceSum+=significantOccurence/totalSignificantOccurrences;

        if (totalWeight>0)
            weightedAbsoluteOccurrence=weightedAbsoluteOccurrence/totalWeight;

        metrics.setOccurrence(occurrence);
        metrics.setAbsoluteOccurrence(absoluteOccurrence);
        metrics.setWeightedOccurrence(weightedOccurrenceSum);
        metrics.setWeightedAbsoluteOccurrence(weightedAbsoluteOccurrence);
        metrics.setSignificantOccurrence(significantOccurrenceSum);
    }

    /**
     * Set a new set of string match metric parameters
     * The parameter are {@link StringMatchMetricsParameters#freeze frozen} if they wasn't already.
     * This may cause validation exceptions to be thrown from here.
     */
    public void setParameters(StringMatchMetricsParameters parameters) {
        parameters.freeze();
        this.parameters=parameters;
    }

    public StringMatchMetricsParameters getParameters() { return parameters; }

    public Query getQuery() { return query; }

    public String[] getField() { return field; }

    /** Returns a textual trace of the last execution of this algorithm, if tracing is on */
    public StringBuilder getTrace() { return trace; }

    /** Set to true to collect a textual trace from the computation, which can be retrieved using {@link #getTrace} */
    public void setCollectTrace(boolean collectTrace) { this.collectTrace=collectTrace; }
    public boolean getCollectTrace() { return collectTrace; }

    /** Returns the last calculated metrics of this, or the null metrics if none has been calculated */
    public StringMatchMetrics getMetrics() {
        if (finalMetrics==null) return new StringMatchMetrics();
        return finalMetrics;
    }

    public String toString() {
        return query + "\nfield: " + Arrays.toString(field) + "\n" + currentMetrics + "\n";
    }
    
}
